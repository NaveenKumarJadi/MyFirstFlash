package com.springboot.crudoperations.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.crudoperations.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}

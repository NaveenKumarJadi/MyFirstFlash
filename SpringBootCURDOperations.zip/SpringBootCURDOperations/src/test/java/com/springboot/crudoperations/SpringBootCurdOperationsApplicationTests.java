package com.springboot.crudoperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCurdOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
